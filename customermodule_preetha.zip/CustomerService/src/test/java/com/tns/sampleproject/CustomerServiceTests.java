package com.tns.sampleproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerServiceTests {

	@Test
	void contextLoads() {
	}

}
