package com.tns.sampleproject;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class CustomerService {
	
	
		@Autowired
		private CustomerRepository repo;
		
		public void save(Customer custo)
		{
			repo.save(custo);
		}
		
		public List<Customer> getAllCustomer()
		{
			return repo.findAll();
		}
		
		public Customer getCustomerById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteCustomer(Integer id)
		{
			repo.deleteById(id);
		}

		public void updateCustomer(Integer id , Customer updatedCustomer)
		{
			Customer existingCustomer = repo.findById(id).orElse(null);
			if (existingCustomer != null)
			{
				existingCustomer.setFirstName(updatedCustomer.getFirstName());
				existingCustomer.setLastName(updatedCustomer.getLastName());
				existingCustomer.setOrderID(updatedCustomer.getOrderID());
				existingCustomer.setPhoneNo(updatedCustomer.getPhoneNo());
				existingCustomer.setEmailId(updatedCustomer.getEmailId());
				repo.save(existingCustomer);
			}
		}
		
		
}
