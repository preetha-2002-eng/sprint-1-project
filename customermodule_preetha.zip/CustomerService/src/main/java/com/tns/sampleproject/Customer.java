package com.tns.sampleproject;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Customer {

		@Id
		@Column(name="customerID")
		private int customerID;
		
		@Column(name="firstName")
		private String firstName;
		
		@Column(name="lastName")
		private String lastName;
		
		@Column(name="orderID")
		private String orderID;
		
		@Column(name="phoneNo")
		private String phoneNo;
		
		@Column(name="emailId")
		private String emailId;

		public int getCustomerID() {
			return customerID;
		}

		public void setCustomerID(int customerID) {
			this.customerID = customerID;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getOrderID() {
			return orderID;
		}

		public void setOrderID(String orderID) {
			this.orderID = orderID;
		}

		public String getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		
		public Customer() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Customer(int customerID, String firstName, String lastName, String orderID, String phoneNo, String emailId) {
			super();
			this.customerID = customerID;
			this.firstName = firstName;
			this.lastName = lastName;
			this.orderID = orderID;
			this.phoneNo = phoneNo;
			this.emailId = emailId;
		}

		@Override
		public String toString() {
			return "Customer [customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName+ ", orderID=" + orderID + ", phoneNo=" + phoneNo + ", emailId=" + emailId ;
		}

}

